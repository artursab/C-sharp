﻿
//method Resize that edit quantity of massive elements
//method must + or - quantity of massive elements

class Program
{

    static void Resize<T>(ref T[] array, int newSize)
    {
        T[] newArray = new T[newSize];

        for (int i = 0; i < newArray.Length && i < newArray.Length; i++)
                newArray[i] = array[i];

        array = newArray;
    }

    static void Main(string[] args)
    {
        int[] myArray = { 1, 2, 6 };

        Resize(ref myArray, 10);
    }
}
