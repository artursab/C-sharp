﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lessons
{
    internal class Program
    {
        static void Main(string[] args)
        {

            bool infected = false;

            if (infected)
            {
                Console.WriteLine("Infected!");
            }
            else
            {
                Console.WriteLine("Not Infected!");
            }

        }
    }
}
